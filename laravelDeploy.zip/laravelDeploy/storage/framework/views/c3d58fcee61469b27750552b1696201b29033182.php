

<div class="col-3 py-3 mb-3 game">
    <div class="card h-100 border-0">
        <a href="<?php echo e(route('detail', $book['book_id'])); ?>"
            data-bs-toggle="tooltip" 
            data-bs-placement="top" 
            title="<?php echo e($book['book_name']); ?>"
        >
            <img class="card-img-top game-img center-img" src="images/book/<?php echo e($book['img']); ?>" alt="..." />
        </a>
        <div class="card-body">
            <div class="text-center">
                <a 
                    class="text-decoration-none text-dark"
                    href=""
                    data-bs-toggle="tooltip" 
                    data-bs-placement="top" 
                    title="<?php echo e($book['book_name']); ?>"
                >
                    <p class=""><?php echo e($book['book_name']); ?></p>
                </a>
            </div>
        </div>
        <div class="text-center d-flex justify-content-center align-items-end">
            <h5 class="text-danger "><?php echo e($book['price']); ?> đ</h5>
        </div>
        <div class="card-footer border-top-0 bg-transparent">
            
            <div class="align-text-bottom">
                <div>
                    <a href="" class="btn btn-outline-primary col-12">
                        <i class="fa-solid fa-cart-shopping fa-lg"></i> Mua ngay
                    </a>
                </div>
                <div class="pt-2">
                    <a href="<?php echo e(route('detail', $book['book_id'])); ?>" class="btn btn-primary col-12">
                        Thông tin chi tiết
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\studies\PHP\laravelDeploy\resources\views/components/books/book-item.blade.php ENDPATH**/ ?>