<title><?php echo e($title); ?></title>

<div>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark justify-content-center">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(route('index')); ?>">&nbsp;</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('index')); ?>"><i class="fa-solid fa-house"></i> Trang Chủ</a>
                    </li>
                    <div class="collapse navbar-collapse">
                        <ul class="navbar-nav">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#"
                                    role="button" aria-expanded="false"><i class="fa-solid fa-bars"></i> Thể Loại</a>
                                <ul class="dropdown-menu dropdown-menu-dark">
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a class="dropdown-item" href="#"><?php echo e($item['cat_name']); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </ul>
            </div>

            <div class="flex-grow-1 d-flex">
                <form class="d-flex form-inline flex-nowrap mx-0 mx-lg-auto p-1" method="GET">
                    <input class="form-control me-2" name="search" type="text" placeholder="Tìm kiếm"
                        aria-label="Search">
                    <button class="btn btn-outline-info" type="submit"><i class="fa-solid fa-magnifying-glass"></i>
                        Tìm</button>
                </form>
            </div>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?mod=cart"><i class="fa-solid fa-cart-shopping"></i> Giỏ
                            Hàng</a>
                    </li>
                    <li class="nav-item dropdown">
                       
                            <?php if(!isset($_REQUEST['user'])): ?>
                            <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button"
                            aria-expanded="false"><i class="fa-solid fa-user"></i> Tài Khoản</a>
                            <ul class="dropdown-menu dropdown-menu-dark">
                                <li><a class="dropdown-item" href=" <?php echo e(route('login')); ?> ">Đăng Nhập</a></li>
                                <li><a class="dropdown-item" href="#">Đăng Ký</a></li>
                            </ul>
                            <?php else: ?>
                            <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button"
                            aria-expanded="false"><i class="fa-solid fa-user"></i> <?php echo e($_REQUEST['user']); ?></a>
                            <ul class="dropdown-menu dropdown-menu-dark">
                                <li><a class="dropdown-item" href=" # ">Thông tin</a></li>
                                <li><a class="dropdown-item" href="#">Đăng xuất</a></li>
                            </ul>
                            <?php endif; ?>
                        
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</div>
<?php /**PATH D:\studies\PHP\laravelDeploy\resources\views/components/header.blade.php ENDPATH**/ ?>