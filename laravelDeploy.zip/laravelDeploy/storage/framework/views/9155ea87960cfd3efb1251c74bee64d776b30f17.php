<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->make('cdn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</head>

<body>
    <div>
         <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, ['title' => 'Trang Chủ','category' => $category]); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>

    <div class="container py-4">
        <swiper-container 
            style="--swiper-navigation-color: #3faede; --swiper-pagination-color: #fff" 
            class="mySwiper shadow-sm rounded"
            navigation="true"
            loop="true"
            space-between="30"
            centered-slides="true" 
            autoplay-delay="2500" 
            autoplay-disable-on-interaction="false"
        >
            <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if (isset($component)) { $__componentOriginal66961a251a577dcdc5d60c18d17bac5ef2902bc5 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Books\Carouselitem::class, ['banner' => $new]); ?>
<?php $component->withName('books.carouselitem'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal66961a251a577dcdc5d60c18d17bac5ef2902bc5)): ?>
<?php $component = $__componentOriginal66961a251a577dcdc5d60c18d17bac5ef2902bc5; ?>
<?php unset($__componentOriginal66961a251a577dcdc5d60c18d17bac5ef2902bc5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </swiper-container>
    </div>

    <div class="container">
        <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if (isset($component)) { $__componentOriginala3d177470851fae72844d7c15be9fcea19610d58 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Books\BookItem::class, ['book' => $item]); ?>
<?php $component->withName('books.book-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginala3d177470851fae72844d7c15be9fcea19610d58)): ?>
<?php $component = $__componentOriginala3d177470851fae72844d7c15be9fcea19610d58; ?>
<?php unset($__componentOriginala3d177470851fae72844d7c15be9fcea19610d58); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="container text-center d-flex justify-content-center">
        <div class="text-center">
            <?php echo e($books->links()); ?>

        </div>
    </div>
</body>

</html>
<?php /**PATH D:\studies\PHP\laravelDeploy\resources\views/index.blade.php ENDPATH**/ ?>