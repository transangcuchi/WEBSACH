<swiper-slide class=""><img src="images/banner/{{ $banner['img'] }}" alt=""></swiper-slide>
